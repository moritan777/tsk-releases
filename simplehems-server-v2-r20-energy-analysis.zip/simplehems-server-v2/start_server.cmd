@echo off
cd /d "%~dp0"
start "SimpleHEMS HotDenki Sync" /min py -3.14 tools\hotdenki_scheduler.py
if exist ".venv\Scripts\python.exe" (".venv\Scripts\python.exe" backend\server.py) else (py -3 backend\server.py)
