@echo off
setlocal
cd /d "%~dp0.."
if "%~2"=="" (
  echo Usage: tools\sync_hotdenki.cmd FROM_DATE TO_DATE
  echo Example: tools\sync_hotdenki.cmd 2026-01-01 2026-10-03
  exit /b 2
)
.venv\Scripts\python.exe tools\hotdenki_sync.py --from "%~1" --to "%~2" --simplehems http://127.0.0.1:8787
pause
