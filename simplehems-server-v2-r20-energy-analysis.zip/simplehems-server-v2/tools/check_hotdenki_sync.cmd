@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
if not exist ".venv\Scripts\python.exe" (
  echo NG: .venv not found
  pause
  exit /b 1
)
set "PY=%CD%\.venv\Scripts\python.exe"
echo Python:
"%PY%" --version
echo.
echo Playwright package:
"%PY%" -m pip show playwright
echo.
echo Import test:
"%PY%" -c "from playwright.sync_api import sync_playwright; print('OK: playwright.sync_api')"
if errorlevel 1 (
  echo NG: Playwright is not installed in this .venv.
  pause
  exit /b 1
)
echo.
echo Browser launch test:
"%PY%" -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); b=p.chromium.launch(headless=True); print('OK: Chromium launched'); b.close(); p.stop()"
if errorlevel 1 (
  echo NG: Chromium is not installed. Run install_hotdenki_sync.cmd.
  pause
  exit /b 1
)
echo.
echo All checks passed.
pause
