#!/usr/bin/env python3
"""Synchronize hotdenki hourly PV generation into SimpleHEMS using a logged-in browser."""
import argparse,json,re,sys,time
from datetime import date,datetime,timedelta,timezone
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError

JST=timezone(timedelta(hours=9))
ROOT=Path(__file__).resolve().parents[1]
PROFILE=ROOT/'tools'/'hotdenki_profile'
RAW=ROOT/'imports'/'raw'
NORMALIZED=ROOT/'imports'/'normalized'
CREDENTIALS=ROOT/'secrets'/'hotdenki_credentials.json'
LOGIN_URL='https://hotdenki.jp/jibunden/login'
GRAPH_URL='https://hotdenki.jp/mypage/graph'
REPORT_RE=re.compile(r'/api/contracts/([^/]+)/report')

def parse_day(s):
 try:return datetime.strptime(s,'%Y-%m-%d').date()
 except ValueError:raise ValueError(f'日付はYYYY-MM-DD形式で指定してください: {s}')

def days(start,end):
 d=start
 while d<=end:yield d;d+=timedelta(days=1)

def number(value,field):
 if value is None:return None
 if isinstance(value,bool):raise ValueError(f'{field}: 真偽値は使用できません')
 try:n=float(value)
 except (TypeError,ValueError):raise ValueError(f'{field}: 数値ではありません: {value!r}')
 if n<0:raise ValueError(f'{field}: 0未満は使用できません')
 return n

def normalize(raw,target_day,contract_reference='default'):
 if not isinstance(raw,dict):raise ValueError('API応答のルートがオブジェクトではありません')
 if raw.get('no_data') is True:return None
 if raw.get('scale')!='hourly':raise ValueError(f"scaleがhourlyではありません: {raw.get('scale')!r}")
 reports=raw.get('reports')
 if not isinstance(reports,list) or not reports:raise ValueError('reportsが空です')
 base=datetime(target_day.year,target_day.month,target_day.day,tzinfo=JST);records=[];seen=set()
 for i,item in enumerate(reports):
  if not isinstance(item,dict):raise ValueError(f'reports[{i}]がオブジェクトではありません')
  try:hour=int(item.get('date'))
  except (TypeError,ValueError):raise ValueError(f'reports[{i}].dateが整数ではありません')
  if not 1<=hour<=24:raise ValueError(f'reports[{i}].dateが1～24ではありません: {hour}')
  if hour in seen:raise ValueError(f'時間が重複しています: {hour}')
  seen.add(hour);generation=number(item.get('pv_generation'),f'reports[{i}].pv_generation')
  if generation is None:raise ValueError(f'reports[{i}].pv_generationがnullです')
  grid=number(item.get('grid_usage'),f'reports[{i}].grid_usage')
  stamp=base+timedelta(hours=hour-1)
  records.append({'timestamp':stamp.isoformat(timespec='seconds'),'interval_minutes':60,'generation_kwh':generation,'grid_usage_kwh':grid,'quality':'provider_actual'})
 return {'schema':'simplehems-generation-import','version':1,'created_at':datetime.now(JST).isoformat(timespec='seconds'),'source':{'service':'hotdenki','display_name':'ほっとでんき','contract_reference':contract_reference},'period':{'from':base.isoformat(timespec='seconds'),'to':(base+timedelta(days=1)).isoformat(timespec='seconds'),'timezone':'Asia/Tokyo'},'granularity':'hourly','unit':'kWh','records':records}

def post_json(url,body,timeout=30):
 data=json.dumps(body,ensure_ascii=False).encode('utf-8');req=Request(url,data=data,method='POST',headers={'Content-Type':'application/json'})
 try:
  with urlopen(req,timeout=timeout) as r:return json.loads(r.read().decode('utf-8'))
 except HTTPError as e:raise RuntimeError(f'SimpleHEMS HTTP {e.code}: {e.read().decode("utf-8",errors="replace")}')
 except URLError as e:raise RuntimeError(f'SimpleHEMSへ接続できません: {e.reason}')

def load_credentials(path=CREDENTIALS):
 if not path.exists():return None
 try:data=json.loads(path.read_text(encoding='utf-8'))
 except (OSError,json.JSONDecodeError) as e:raise RuntimeError(f'認証情報ファイルを読み込めません: {path}: {e}')
 login_id=str(data.get('login_id','')).strip();password=str(data.get('password',''))
 if not login_id or not password:raise RuntimeError(f'認証情報ファイルにlogin_idまたはpasswordがありません: {path}')
 return login_id,password

def is_login_page(page):
 return '/login' in page.url or page.locator('input[type="password"]').count()>0

def auto_login(page,credentials):
 if not credentials:raise RuntimeError('ログインが必要です。tools/set_hotdenki_credentials.pyを実行して認証情報を保存してください。')
 login_id,password=credentials
 page.wait_for_selector('input[type="text"]',timeout=30000)
 page.locator('input[type="text"]').first.fill(login_id)
 page.locator('input[type="password"]').first.fill(password)
 submit=page.locator('input[type="submit"]').first
 if submit.count()==0:raise RuntimeError('ログイン送信ボタンを検出できませんでした。')
 print('ログイン画面を検出しました。保存済み認証情報でログインします。')
 submit.click()
 try:page.wait_for_url(lambda url:'/login' not in url,timeout=30000)
 except Exception:
  page.wait_for_timeout(2000)
  if is_login_page(page):raise RuntimeError('自動ログインに失敗しました。ID、パスワード、画面仕様を確認してください。')
 print('自動ログインに成功しました。')

def discover_contract(page,timeout_ms,credentials=None):
 found=[]
 def observe(response):
  match=REPORT_RE.search(response.url)
  if match and match.group(1) not in found:found.append(match.group(1))
 page.on('response',observe);page.goto(GRAPH_URL,wait_until='domcontentloaded')
 if is_login_page(page):
  auto_login(page,credentials);page.goto(GRAPH_URL,wait_until='domcontentloaded')
 deadline=time.time()+timeout_ms/1000
 while time.time()<deadline and not found:
  if is_login_page(page):
   auto_login(page,credentials);page.goto(GRAPH_URL,wait_until='domcontentloaded')
  page.wait_for_timeout(1000)
 if not found:
  page.reload(wait_until='domcontentloaded');page.wait_for_timeout(4000)
 return found[0] if found else None

def fetch_report(page,contract_id,d):
 url=f'https://hotdenki.jp/api/contracts/{contract_id}/report?scale=hourly&year={d.year}&month={d.month}&date={d.day}'
 result=page.evaluate("""async (url) => {const r=await fetch(url,{credentials:'include',headers:{Accept:'application/json'}});const text=await r.text();return {status:r.status,text};}""",url)
 if result['status'] in (401,403):raise RuntimeError('ログインセッションが切れています。再ログインしてください。')
 if result['status']>=400:raise RuntimeError(f"ほっとでんきAPI HTTP {result['status']}: {result['text'][:200]}")
 try:return json.loads(result['text'])
 except json.JSONDecodeError:raise RuntimeError('ほっとでんきAPIがJSON以外を返しました。')

def main(argv=None):
 ap=argparse.ArgumentParser(description='ログイン済みブラウザーからほっとでんき発電量を取得し、SimpleHEMSへ同期します。')
 ap.add_argument('--from',dest='start',required=True,help='開始日 YYYY-MM-DD')
 ap.add_argument('--to',dest='end',required=True,help='終了日 YYYY-MM-DD')
 ap.add_argument('--simplehems',default='http://127.0.0.1:8787',help='SimpleHEMS URL')
 ap.add_argument('--contract-id',help='ほっとでんき契約ID。省略時は通信から自動検出')
 ap.add_argument('--contract-reference',default='default',help='SimpleHEMS内の契約参照名')
 ap.add_argument('--save-only',action='store_true',help='JSON保存のみでSimpleHEMSへ送信しない')
 ap.add_argument('--headless',action='store_true',help='ブラウザーを非表示。Cookie失効時は保存済み認証情報で自動ログイン')
 ap.add_argument('--delay',type=float,default=.5,help='APIアクセス間隔（秒）')
 args=ap.parse_args(argv)
 try:
  start,end=parse_day(args.start),parse_day(args.end)
  if start>end:raise ValueError('開始日は終了日以前にしてください')
  if (end-start).days>366:raise ValueError('一度に取得できる期間は367日以内です')
  from playwright.sync_api import sync_playwright
  PROFILE.mkdir(parents=True,exist_ok=True);RAW.mkdir(parents=True,exist_ok=True);NORMALIZED.mkdir(parents=True,exist_ok=True)
  with sync_playwright() as pw:
   context=pw.chromium.launch_persistent_context(str(PROFILE),headless=args.headless,viewport={'width':1280,'height':900})
   page=context.pages[0] if context.pages else context.new_page();credentials=load_credentials();contract=args.contract_id or discover_contract(page,180000,credentials)
   if not contract:raise RuntimeError('契約APIを検出できませんでした。発電量の推移画面を開いて再実行してください。')
   print('契約APIを検出しました。発電データの取得を開始します。')
   added=updated=unchanged=nodata=errors=0
   for d in days(start,end):
    try:
     raw=fetch_report(page,contract,d);raw_path=RAW/f'hotdenki-{d:%Y%m%d}-hourly.json';raw_path.write_text(json.dumps(raw,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
     normalized=normalize(raw,d,args.contract_reference)
     if normalized is None:nodata+=1;print(f'{d}: データなし');continue
     out_path=NORMALIZED/f'simplehems-generation-{d:%Y%m%d}.json';out_path.write_text(json.dumps(normalized,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
     total=sum(x['generation_kwh'] for x in normalized['records'])
     if args.save_only:print(f'{d}: {len(normalized["records"])}件 {total:.3f} kWh 保存');continue
     result=post_json(args.simplehems.rstrip('/')+'/api/import/generation',normalized);added+=result.get('inserted',0);updated+=result.get('updated',0);unchanged+=result.get('unchanged',0)
     print(f'{d}: {total:.3f} kWh / 新規 {result.get("inserted",0)} 更新 {result.get("updated",0)} 変更なし {result.get("unchanged",0)}')
    except Exception as e:errors+=1;print(f'{d}: 失敗: {e}',file=sys.stderr)
    time.sleep(max(0,args.delay))
   context.close()
  print(f'完了: 新規 {added} / 更新 {updated} / 変更なし {unchanged} / データなし {nodata} / 失敗 {errors}')
  return 1 if errors else 0
 except ModuleNotFoundError as e:
  if e.name=='playwright':print('同期失敗: PlaywrightがこのPython環境にありません。tools/install_hotdenki_sync.cmdを実行してください。',file=sys.stderr);return 2
  print(f'同期失敗: {e}',file=sys.stderr);return 1
 except Exception as e:print(f'同期失敗: {e}',file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
