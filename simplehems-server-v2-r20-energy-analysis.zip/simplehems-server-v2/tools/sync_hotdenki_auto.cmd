@echo off
setlocal
cd /d "%~dp0.."
py -3.14 tools\hotdenki_auto.py --initial-from 2026-01-01 --simplehems http://127.0.0.1:8787
set "RC=%ERRORLEVEL%"
pause
exit /b %RC%
