@echo off
setlocal
cd /d "%~dp0.."
if "%~2"=="" (
  echo Usage: tools\sync_hotdenki_save_only.cmd FROM_DATE TO_DATE
  exit /b 2
)
.venv\Scripts\python.exe tools\hotdenki_sync.py --from "%~1" --to "%~2" --save-only
pause
