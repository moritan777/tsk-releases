ほっとでんきJSON変換ツール

1. Chrome開発者ツールの Network で scale=hourly の通信を選びます。
2. Responseタブ内のJSONだけをファイルへ保存します。Cookie、Headers、契約IDは保存不要です。
3. コマンドプロンプトでSimpleHEMSフォルダーへ移動します。
4. 次を実行します。

  tools\convert_hotdenki.cmd hotdenki-raw.json 2026-10-01 simplehems-generation-20261001.json

5. Dashboardの「設定・システム」→「発電量JSON取込み」で、生成したJSONを選びます。

注意:
- 入力は scale=hourly 専用です。
- --date は、ほっとでんき画面で選択した対象日です。
- date=1..24 は、0:00開始の24個の時間帯として変換します。
- grid_usage=null は0へ変換せず、そのままnullで保存します。
