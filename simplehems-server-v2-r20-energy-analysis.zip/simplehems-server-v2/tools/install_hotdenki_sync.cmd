@echo off
setlocal EnableExtensions
cd /d "%~dp0.."

echo [1/5] Checking virtual environment...
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv\Scripts\python.exe was not found.
  echo Run install_windows.cmd first, then run this file again.
  pause
  exit /b 1
)
set "PY=%CD%\.venv\Scripts\python.exe"

echo [2/5] Checking Python...
"%PY%" --version
if errorlevel 1 goto :fail

echo [3/5] Installing Playwright package into this .venv...
"%PY%" -m ensurepip --upgrade
if errorlevel 1 goto :fail
"%PY%" -m pip install --upgrade pip
if errorlevel 1 goto :fail
"%PY%" -m pip install --upgrade playwright
if errorlevel 1 goto :fail

echo [4/5] Verifying Python import...
"%PY%" -c "from playwright.sync_api import sync_playwright; print('Playwright Python import OK')"
if errorlevel 1 goto :fail

echo [5/5] Installing Playwright Chromium...
"%PY%" -m playwright install chromium
if errorlevel 1 goto :fail

echo.
echo Installation completed successfully.
echo Run: tools\sync_hotdenki.cmd YYYY-MM-DD YYYY-MM-DD
pause
exit /b 0

:fail
echo.
echo ERROR: Installation failed at the step shown above.
echo Copy the complete error text from this window.
pause
exit /b 1
