@echo off
schtasks /delete /f /tn "SimpleHEMS Server"
pause
