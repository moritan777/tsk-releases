SimpleHEMS Server v2

Upgrade from v1:
1. Stop start_server.cmd with Ctrl+C.
2. Keep a copy of C:\simplehems\data\simplehems.db.
3. Replace backend, frontend, config.json and cmd files with v2.
4. Put the preserved simplehems.db back in data.
5. Run start_server.cmd and open http://localhost:8787.

The database is not included in this ZIP. Existing history can be preserved.
