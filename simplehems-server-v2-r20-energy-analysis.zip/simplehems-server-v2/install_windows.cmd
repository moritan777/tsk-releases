@echo off
cd /d "%~dp0"
where py >nul 2>nul || (echo Python 3 is required. & pause & exit /b 1)
py -3 -m venv .venv
if not exist frontend\dist\index.html (echo frontend build missing. & pause & exit /b 1)
echo Installed. Run start_server.cmd and open http://localhost:8787
pause
